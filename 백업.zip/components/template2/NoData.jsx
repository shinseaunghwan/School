
import React from 'react';
import widget from "../../styles/template2/T0002_widget.module.css"
export default function NoData() {
  return <li className={widget.no_data}>데이터가 없습니다.</li>
}
