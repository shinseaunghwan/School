
import React from 'react';

export default function Title (props) {
  return <h2 className={props.className}>{props.children}</h2>;
}
